A delayed send that has some or all of the arguments defined in advance. Additionally supplied arguments will be added, if possible, to these when the object is evaluate.

Instance Variables
	arguments:		<Array>

arguments
	- the predefined arguments
