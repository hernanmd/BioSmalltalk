A GRCountingStream counts how many elements have been added to it. This is necessary because the underlying stream may inflate the number of elements in the stream.

Instance Variables:
	count	<Integer>
		
count
  - number of elements added to this stream