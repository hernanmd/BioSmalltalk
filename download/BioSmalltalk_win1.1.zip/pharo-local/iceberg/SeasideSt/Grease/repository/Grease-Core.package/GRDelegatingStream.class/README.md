A GRDelegatingStream is a wrapper around a write stream and defines common behavior.

Instance Variables
	stream:		<WriteStream>

stream
	- a WriteStream

