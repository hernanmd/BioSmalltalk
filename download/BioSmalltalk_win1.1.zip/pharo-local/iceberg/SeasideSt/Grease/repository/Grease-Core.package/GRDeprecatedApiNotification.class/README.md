This notification is signaled whenever a deprecated message is sent.

see WAObject>>#greaseDeprecatedApi:details: 