A WAInvalidUtf8Error signals that the input is not valid UTF-8.
