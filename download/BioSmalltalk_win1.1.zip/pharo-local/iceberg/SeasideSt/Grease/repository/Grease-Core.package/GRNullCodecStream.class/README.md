A WANullCodecStream is a WriteStream on a String on which you can both put binary and character data without encoding happening.

Instance Variables
	stream:		<WriteStream>

stream
	- a WriteStream on a String
