A GRNumberPrinter prints numbers (integers and floats) in various formats in a platform independent way.

Instance Variables
	accuracy:	<UndefinedObject|Float>
	base:		<Integer>
	delimiter:	<UndefinedObject|Character>
	digits:		<UndefinedObject|Integer>
	infinite:		<UndefinedObject|String>
	nan:			<UndefinedObject|String>
	padding:	<UndefinedObject|Character>
	precision:	<Integer>
	separator:	<UndefinedObject|Character>