A common superclass that ensures consistent initialization behaviour on all platforms and provides #error: methods that signal an instance of WAPlatformError.

Packages that are using Seaside-Platform should normally subclass GRObject instead of Object.