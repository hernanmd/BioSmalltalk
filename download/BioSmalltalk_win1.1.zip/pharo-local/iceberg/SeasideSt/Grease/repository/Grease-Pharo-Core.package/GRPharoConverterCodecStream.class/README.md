A GRPharoConverterCodecStream is a WACodec stream around a TextConverter. It is always in text mode.

Instance Variables
	converter:		<TextConverter>

converter
	- the TextConverter used to do the encoding conversion
