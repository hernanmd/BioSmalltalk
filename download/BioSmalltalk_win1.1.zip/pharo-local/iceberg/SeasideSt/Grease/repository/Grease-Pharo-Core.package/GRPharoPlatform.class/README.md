A GRPharoPlatform is the Pharo implementation of GRPlatform, the Grease class that provides functionality that can not be implemented in a platform independent way.
