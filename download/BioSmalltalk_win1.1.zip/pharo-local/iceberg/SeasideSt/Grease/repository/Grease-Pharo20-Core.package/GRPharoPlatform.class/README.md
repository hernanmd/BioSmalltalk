A WASqueakPlatform is the Squeak implementation of SeasidePlatformSupport, the Seaside class that provides functionality that can not be implemented in a platform independent way.
