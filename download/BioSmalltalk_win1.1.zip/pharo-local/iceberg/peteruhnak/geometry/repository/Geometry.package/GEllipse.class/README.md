I am an Ellipse geometry.

I am described by center and two radii.

- `center `is the center point of the ellipse
- `a` is the major radius along the x axis
- `b` is the minor radius along the y axis