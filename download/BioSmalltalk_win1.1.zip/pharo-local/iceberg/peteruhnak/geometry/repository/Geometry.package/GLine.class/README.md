A GLine has 3 instance variables, which are koeficients  of line:
ax+by+c=0

