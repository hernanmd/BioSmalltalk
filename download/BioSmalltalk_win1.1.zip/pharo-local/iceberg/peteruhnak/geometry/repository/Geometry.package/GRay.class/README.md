I am a vector builded on line ax+by+c=0 and have my start in point v1.

